package org.finework.com.notice;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/com/notice/*")
public class ComNoticeController {

    @Inject
    private ComNoticeService comNoticeService;

    // 공고 등록 폼
    @GetMapping("/register")
    public void register() {}

    // 공고 등록 처리
    @PostMapping("/register")
    public String registerPost(ComNoticeVO vo) throws Exception {
        comNoticeService.register(vo);
        return "redirect:/com/notice/list?com_id="+vo.getCom_id();
    }

    // 공고 목록 + 검색 기능
    @GetMapping("/list")
    public String list(@RequestParam("com_id") String com_id, Model model) throws Exception {

        List<ComNoticeVO> list = comNoticeService.getListByComId(com_id);

        model.addAttribute("noticeList", list);
        return "/com/notice/list";
    }

    // 공고 상세보기
    @GetMapping("/detail")
    public void detail(@RequestParam("com_notice_id") int com_notice_id, Model model) throws Exception {
        model.addAttribute("notice", comNoticeService.getNotice(com_notice_id));
    }

    // 공고 수정 폼
    @GetMapping("/modify")
    public void modify(@RequestParam("com_notice_id") int com_notice_id, Model model) throws Exception {
        model.addAttribute("notice", comNoticeService.getNotice(com_notice_id));
    }

    // 공고 수정 처리
    @PostMapping("/modify")
    public String modifyPost(ComNoticeVO vo, Model model, RedirectAttributes rttr) throws Exception {
    	    
        int result = comNoticeService.modify(vo);
        String url = null;
        
        if (result != 0) {
        	url = "/com/notice/notice_modify_ok";
        } else {
        	rttr.addFlashAttribute("com_notice_id", vo.getCom_notice_id());
        	url = "redirect:/com/notice/notice_modify_ex";
        }
        
        return url;
    }
    
    @GetMapping("/notice_modify_ok")
    public void notice_modify_ok() {};
    
    @GetMapping("/notice_modify_ex")
    public void notice_modify_ex() {};
    

    // 공고 삭제
    @GetMapping("/delete")
    public String delete(@RequestParam("com_notice_id") int com_notice_id) throws Exception {
        
    	int result = comNoticeService.delete(com_notice_id);
        String url = null;
        
        if (result != 0) {
        	url = "/com/notice/notice_delete_ok";
        } else {
        	url = "/com/notice/notice_delete_ex";
        }
        
        return url;
    }
    
    @GetMapping("/notice_delete_ok")
    public void notice_delete_ok() {};
    
    @GetMapping("/notice_delete_ex")
    public void notice_delete_ex() {};
    
}
