package org.finework.com.notice;

import java.util.List;

public interface ComNoticeService {

	public int register(ComNoticeVO noticeVO) throws Exception;

	public ComNoticeVO getNotice(int com_notice_id) throws Exception;

	public List<ComNoticeVO> getList() throws Exception;

	public int modify(ComNoticeVO noticeVO) throws Exception;

	public int delete(int com_notice_id) throws Exception;
	
	public List<ComNoticeVO> getListByComId(String com_id) throws Exception;
}
