package org.finework.com.notice;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class ComNoticePersistenceImpl implements ComNoticePersistence {

    @Inject
    private SqlSession sqlSession;

    private static final String namespace = "org.finework.mapper.ComNoticeMapper";

    @Override
    public int register(ComNoticeVO vo) throws Exception {
        return sqlSession.insert(namespace + ".register", vo);
    }

    @Override
    public ComNoticeVO getNotice(int com_notice_id) throws Exception {
       	
        return sqlSession.selectOne(namespace + ".getNotice", com_notice_id);
    }
    
    @Override
    public List<ComNoticeVO> getListByComId(String com_id) throws Exception {
        return sqlSession.selectList(namespace + ".getListByComId", com_id);
    }

    @Override
    public List<ComNoticeVO> getList() throws Exception {
        return sqlSession.selectList(namespace + ".getList");
    }

    @Override
    public int modify(ComNoticeVO vo) throws Exception {
        return sqlSession.update(namespace + ".modify", vo);
    }

    @Override
    public int delete(int com_notice_id) throws Exception {
    	
        return sqlSession.delete(namespace + ".delete", com_notice_id);
    }

}
