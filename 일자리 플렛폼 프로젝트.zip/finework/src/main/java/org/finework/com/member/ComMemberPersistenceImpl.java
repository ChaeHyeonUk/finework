package org.finework.com.member;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

@Repository
public class ComMemberPersistenceImpl implements ComMemberPersistence {
	
	@Inject
	private SqlSession sqlSession; // SQL문을 실행하는 내장객체
	
	private String namespace="org.finework.mappers.commember";
	
	@Override
	public ComMemberVO idCheck(String com_id) throws Exception {
		
		return sqlSession.selectOne(namespace+".idcheck", com_id);
	}
	
	 // 아이디 찾기
    @Override
    public ComMemberVO idFind(ComMemberVO cmvo) throws Exception {
        return sqlSession.selectOne(namespace + ".idFind", cmvo);
    }
    
    // 비밀번호 찾기
    @Override
    public ComMemberVO com_pwd_find(ComMemberVO cmvo) throws Exception {
        return sqlSession.selectOne(namespace + ".com_pwd_find", cmvo);
    }
    
    
	 // 회원가입
    @Override
    public int register(ComMemberVO cmvo) throws Exception {
        return sqlSession.insert(namespace + ".register", cmvo);
    }

    // 로그인
    @Override
    public ComMemberVO login(ComMemberVO cmvo) throws Exception {
        return sqlSession.selectOne(namespace + ".login", cmvo);
    }

    // 마이페이지 조회
    @Override
    public ComMemberVO getCom(String com_id) throws Exception {
        return sqlSession.selectOne(namespace + ".getCom", com_id);
    }

   

    // 정보 수정
    @Override
    public int modify(ComMemberVO cmvo) throws Exception {
        return sqlSession.update(namespace + ".modify", cmvo);
    }

    // 비밀번호 재설정
    @Override
    public int resetPwd(ComMemberVO cmvo) throws Exception {
        return sqlSession.update(namespace + ".resetPwd", cmvo);
    }

    // 회원 탈퇴
    @Override
    public int delete(String com_id) throws Exception {
        return sqlSession.delete(namespace + ".delete", com_id);
    }
    
    @Override
    public List<AddressVO> getAddrList(AddressVO addr) throws Exception {
        return sqlSession.selectList(namespace + ".getAddrList", addr);
    }
	
}
