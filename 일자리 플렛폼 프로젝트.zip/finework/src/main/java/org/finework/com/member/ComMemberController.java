package org.finework.com.member;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.finework.com.member.ComMemberVO;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/com/member/*")
public class ComMemberController {
	
	@Inject 
	private ComMemberService comMemberService;
	
	@Inject
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@GetMapping("/com_register")
	public String register() throws Exception  {return "/com/member/com_register";}
	
	
	@PostMapping("/com_register")
	public String register(ComMemberVO cmvo) throws Exception {
		String pwd = cmvo.getCom_pwd();
		String encPwd =  bCryptPasswordEncoder.encode(pwd); 
		cmvo.setCom_pwd(encPwd);
		
		int result = comMemberService.register(cmvo);
		
		String url = null;
		
		if(result == 1) {
			url = "/com/member/com_register_ok"; 
		} else {
			url = "/com/member/com_register_ex";
			}
		
		return url;
	}
	
	// 우편번호 검색 화면 (GET)
	@GetMapping("/getAddrList")
	public void getAddrList() throws Exception {
	    // 단순히 getAddrList.jsp를 보여줌
	}

	// 우편번호 검색 실행 (POST)
	@PostMapping("/getAddrList")
	public void getAddrList(AddressVO addr, Model model) throws Exception {
	    List<AddressVO> addrList = comMemberService.getAddrList(addr);
	    model.addAttribute("addrList", addrList);
	}
	
	@PostMapping("/idcheck")
	@ResponseBody
	public String idcheck(HttpServletRequest request) throws Exception {
		String com_id = request.getParameter("com_id");
		
		ComMemberVO cmvo = comMemberService.idCheck(com_id);
		String result = null;
		System.out.println("===============" + com_id);
		
		if (cmvo != null) result = "success";
		
		return result;
	}

	@GetMapping("/login")
	public void login() throws Exception {}
	
	@PostMapping("/login")
	public String login(ComMemberVO cmvo, HttpSession session, RedirectAttributes rttr) throws Exception {
	    ComMemberVO dbcmvo = comMemberService.login(cmvo);
	    String url;

	    if (dbcmvo != null) {
	        boolean flag = bCryptPasswordEncoder.matches(cmvo.getCom_pwd(), dbcmvo.getCom_pwd());
	        
	        if (flag) {
	            session.setAttribute("com", dbcmvo);
	            session.setMaxInactiveInterval(60 * 10);
	            url = "redirect:/";
	        } else {
	            session.setAttribute("com", null);	
	            rttr.addFlashAttribute("com_pwd", false);
	            url = "redirect:/login";
	        	}
		} else {
	        rttr.addFlashAttribute("com_id", false);
	        url = "redirect:/login";
			} 
	        
	    
	    return url;
	}
	
	@GetMapping("/logout")
		public String logout(HttpSession session) throws Exception {
			session.invalidate();
			return "redirect:/";
		}
		
		
	// 아이디 찾기 화면
	@GetMapping("/com_id_find")
	public void com_id_find() throws Exception {}

	// 아이디 찾기 처리
	@PostMapping("/com_id_find")
	public String com_id_find(ComMemberVO cmvo, RedirectAttributes rttr) throws Exception {
	    ComMemberVO dbCmvo = comMemberService.idFind(cmvo);
	    String url = null;
	    
	    if (dbCmvo != null) {
	        rttr.addFlashAttribute("com_id", dbCmvo.getCom_id());
	        url = "redirect:/com/member/com_id_find_ok";
	    } else {
	        url = "redirect:/com/member/com_id_find_ex";
	    }
	    return url;
	}
	
	@GetMapping("/com_id_find_ok")
	public void com_id_find_ok() throws Exception {}
	
	@GetMapping("/com_id_find_ex")
	public void com_id_find_ex() throws Exception {}
	
	// 비밀번호 찾기 처리
	@GetMapping("/com_pwd_find")
	public void com_pwd_find() throws Exception {}
	
	@PostMapping("/com_pwd_find")
	public String com_pwd_find(ComMemberVO cmvo, RedirectAttributes rttr) throws Exception {
	    ComMemberVO dbCmvo = comMemberService.com_pwd_find(cmvo);
	    String url = null;
	    
	    if (dbCmvo != null) {
	    	rttr.addFlashAttribute("com_id", dbCmvo.getCom_id());
	        url = "redirect:/com/member/com_pwd_find_ok";
	    } else {
	        url = "redirect:/com/member/com_pwd_find_ex";
	    }
	    return url;
	}
	
	@GetMapping("/com_pwd_find_ok")
	public void com_pwd_find_ok() throws Exception {}
	
	@GetMapping("/com_pwd_find_ex")
	public void com_pwd_find_ex() throws Exception {}

	// 비밀번호 재설정 화면
	@GetMapping("/reset_pwd")
	public void resetPwd(@RequestParam("com_id") String com_id, Model model) throws Exception {
	    ComMemberVO cmvo = comMemberService.getCom(com_id);
	    model.addAttribute("cmvo", cmvo);
	}
	

	// 비밀번호 재설정 처리
	@PostMapping("/reset_pwd")
	public String resetPwd(HttpSession session, ComMemberVO cmvo) throws Exception {
	    String pwd = cmvo.getCom_pwd();
	    String encPwd = bCryptPasswordEncoder.encode(pwd);
	    cmvo.setCom_pwd(encPwd);

	    int result = comMemberService.resetPwd(cmvo);
	    String url = null;
	    
	    if (result != 0) {
	    	session.invalidate();
	    	url = "/com/member/reset_pwd_ok";
	    } else {
	    	url = "/com/member/reset_pwd_ex";
	    }
	    
	    return url;
	}
	
    @GetMapping("/com_mypage")
    public String comMypage(@RequestParam("com_id") String com_id, HttpSession session, Model model) throws Exception {
        ComMemberVO sessionCom = (ComMemberVO) session.getAttribute("com");
        if (sessionCom != null && sessionCom.getCom_id().equals(com_id)) {
            ComMemberVO cmvo = comMemberService.getCom(com_id);
            model.addAttribute("cmvo", cmvo);
            return "/com/member/com_mypage";
        } else {
            return "redirect:/login";
        }
    }
    

    // 수정 화면 보여주기 (GET)
    @GetMapping("/com_modify")
    public String showModifyForm(@RequestParam("com_id") String com_id, Model model) throws Exception {
        ComMemberVO cmvo = comMemberService.getCom(com_id);
        model.addAttribute("cmvo", cmvo);
        return "/com/member/com_modify"; // 수정 폼 JSP
    }

    // 수정 처리 (POST)
    @PostMapping("/com_modify")
    public String modify(ComMemberVO cmvo) throws Exception {
        int result = comMemberService.modify(cmvo);
        if (result != 0) {
            return "redirect:/com/member/com_mypage?com_id=" + cmvo.getCom_id();
        } else {
            return "redirect:/com/member/modify_ex";
        }
    }
    

		
		@GetMapping("/delete")
		public String delete(@RequestParam("com_id") String com_id, Model model, HttpSession session) throws Exception {
			int result = comMemberService.delete(com_id);
			String url = null;
			
			if (result != 0) {
				session.invalidate();
				url = "redirect:/";
			} else {
				url = "redirect:/com/member/delete_ex";
			}
			return url;
		}
		
	    @GetMapping("/delete_ex")
	    public void delete_ex() throws Exception {}
	

}
