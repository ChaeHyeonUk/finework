package org.finework.com.notice;

import java.util.Date;
import lombok.Data;

@Data
public class ComNoticeVO {
    private int com_notice_id;
    private String com_id;
    private String com_addr;
    private String com_business;
    private String com_title;
    private String com_location;
    private String com_salary_amount;
    private String com_period;
    private String com_schedule;
    private String com_industry;
    private String com_jobtype;
    private String com_end_date;
    private String com_school;
    private int com_recruit_count;
    private String com_career;
    private String com_military_status;
    private String com_intro;
    private String com_contact;
    private String com_contact_tel;
    private String com_contact_email;
    private Date com_notice_reg_date;
    private Date com_notice_mod_date;
}
