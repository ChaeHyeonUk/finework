package org.finework.com.notice;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

@Service
public class ComNoticeServiceImpl implements ComNoticeService {

    @Inject
    private ComNoticePersistence comNoticePersistence;

    @Override
    public int register(ComNoticeVO noticeVO) throws Exception {
        return comNoticePersistence.register(noticeVO);
    }

    @Override
    public ComNoticeVO getNotice(int com_notice_id) throws Exception {
        return comNoticePersistence.getNotice(com_notice_id);
    }

    @Override
    public List<ComNoticeVO> getList() throws Exception {
        return comNoticePersistence.getList();
    }

    @Override
    public int modify(ComNoticeVO noticeVO) throws Exception {
        return comNoticePersistence.modify(noticeVO);
    }

    @Override
    public int delete(int com_notice_id) throws Exception {
        return comNoticePersistence.delete(com_notice_id);
    }
    
    @Override
    public List<ComNoticeVO> getListByComId(String com_id) throws Exception {
        return comNoticePersistence.getListByComId(com_id);
    }
}
