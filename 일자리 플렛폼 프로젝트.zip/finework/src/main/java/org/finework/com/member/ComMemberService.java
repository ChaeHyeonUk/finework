package org.finework.com.member;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.finework.emp.member.EmpMemberVO;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;


public interface ComMemberService {
	
	public ComMemberVO idCheck(String com_id) throws Exception;
	
	   // 회원가입 (Create)
	public int register(ComMemberVO cmvo) throws Exception;

    // 마이페이지 / 단건 조회 (Read)
	public ComMemberVO getCom(String com_id) throws Exception;

    // 회원정보 수정 (Update)
	public int modify(ComMemberVO cmvo) throws Exception;

    // 비밀번호 재설정 (Update)
	public int resetPwd(ComMemberVO cmvo) throws Exception;

    // 회원탈퇴 (Delete)
	public int delete(String com_id) throws Exception;
 
    // 로그인
	public ComMemberVO login(ComMemberVO cmvo) throws Exception;

    // 아이디 찾기
	public ComMemberVO idFind(ComMemberVO cmvo) throws Exception;
	
	// 비밀번호 찾기
	public ComMemberVO com_pwd_find(ComMemberVO cmvo) throws Exception;
	
	public List<AddressVO> getAddrList(AddressVO addr) throws Exception;
    
}

