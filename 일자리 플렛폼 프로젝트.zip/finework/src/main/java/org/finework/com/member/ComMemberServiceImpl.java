package org.finework.com.member;

import java.util.List;

import javax.inject.Inject;

import org.finework.emp.member.EmpMemberVO;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;

@Service // 서비스 빈으로 IoC 컨테이너에 등록된다.
public class ComMemberServiceImpl implements ComMemberService{
	
	@Inject
	private ComMemberPersistence comMemberPersistence;
	
	@Override
	public ComMemberVO idCheck(String com_id) throws Exception  {
		
		return comMemberPersistence.idCheck(com_id);
	}

	 // 아이디 찾기
    @Override
    public ComMemberVO idFind(ComMemberVO cmvo) throws Exception {
        return comMemberPersistence.idFind(cmvo);
    }
    
    @Override
    public ComMemberVO com_pwd_find(ComMemberVO cmvo) throws Exception {
        return comMemberPersistence.com_pwd_find(cmvo);
    }
    
	 // 회원가입
    @Override
    public int register(ComMemberVO cmvo) throws Exception {
        return comMemberPersistence.register(cmvo);
    }

    // 로그인
    @Override
    public ComMemberVO login(ComMemberVO cmvo) throws Exception {
        return comMemberPersistence.login(cmvo);
    }

    // 마이페이지 조회
    @Override
    public ComMemberVO getCom(String com_id) throws Exception {
        return comMemberPersistence.getCom(com_id);
    }

    // 정보 수정
    @Override
    public int modify(ComMemberVO cmvo) throws Exception {
        return comMemberPersistence.modify(cmvo);
    }

    // 비밀번호 재설정
    @Override
    public int resetPwd(ComMemberVO cmvo) throws Exception {
        return comMemberPersistence.resetPwd(cmvo);
    }

    // 회원 탈퇴
    @Override
    public int delete(String com_id) throws Exception {
        return comMemberPersistence.delete(com_id);
    }
    
    @Override
	public List<AddressVO> getAddrList(AddressVO addr) throws Exception {
		return comMemberPersistence.getAddrList(addr);
	}

   
}
