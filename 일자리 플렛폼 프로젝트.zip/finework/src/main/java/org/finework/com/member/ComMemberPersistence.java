package org.finework.com.member;

import java.util.List;

import org.finework.emp.member.EmpMemberVO;
import org.springframework.web.bind.annotation.RequestParam;

public interface ComMemberPersistence {

	public ComMemberVO idCheck(String com_id) throws Exception;
	
	   // 회원가입
    public int register(ComMemberVO cmvo) throws Exception;

    // 로그인 및 단일 조회
    public ComMemberVO login(ComMemberVO cmvo) throws Exception;
    public ComMemberVO getCom(String com_id) throws Exception;

    // 정보 수정
    public int modify(ComMemberVO cmvo) throws Exception;

    // 비밀번호 재설정
    public int resetPwd(ComMemberVO cmvo) throws Exception;

    // 회원탈퇴
    public int delete(String com_id) throws Exception;

    // 아이디 찾기
    public ComMemberVO idFind(ComMemberVO cmvo) throws Exception;
    
    // 비밀번호 찾기
    public ComMemberVO com_pwd_find(ComMemberVO cmvo) throws Exception;
    
    public List<AddressVO> getAddrList(AddressVO addr) throws Exception;
}


