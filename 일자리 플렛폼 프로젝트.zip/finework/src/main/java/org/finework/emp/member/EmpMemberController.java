package org.finework.emp.member;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/emp/member/*")
public class EmpMemberController {
	
	@Inject 
	private EmpMemberService empMemberService;
	
	@Inject
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@GetMapping("/emp_register")
	public void register() throws Exception  {}
	
	
	@PostMapping("/emp_register")
	public String register(EmpMemberVO emvo) throws Exception {
		String pwd = emvo.getEmp_pwd();
		String encPwd =  bCryptPasswordEncoder.encode(pwd); 
		emvo.setEmp_pwd(encPwd);
		
		int result = empMemberService.register(emvo);
		
		String url = null;
		
		if(result == 1) {
			url = "/emp/member/emp_register_ok"; 
		} else {
			url = "/emp/member/emp_register_ex";
			}
		
		return url;
	}
	
	@GetMapping("/getAddrList")
	public void getAddrList() throws Exception {
	}

	@PostMapping("/getAddrList")
	public void getAddrList(AddressVO addr, Model model) throws Exception {
		List<AddressVO> addrList = empMemberService.getAddrList(addr);
	    model.addAttribute("addrList", addrList);
	}
	
	@PostMapping("/idcheck")
	@ResponseBody
	public String idcheck(HttpServletRequest request) throws Exception {
		String emp_id = request.getParameter("emp_id");
		
		EmpMemberVO emvo = empMemberService.idCheck(emp_id);
		String result = null;
		
		if (emvo != null) result = "success";
		
		return result;
	}
	
	@PostMapping("/nickcheck")
	@ResponseBody
	public String nickcheck(HttpServletRequest request) throws Exception {
		String emp_nickname = request.getParameter("emp_nickname");
		
		EmpMemberVO emvo = empMemberService.nickcheck(emp_nickname);
		String result = null;
		
		if (emvo != null) result = "success";
		
		return result;
	}

	@GetMapping("/login")
	public void login() throws Exception {}
	
	@PostMapping("/login")
	public String login(EmpMemberVO emvo, HttpSession session, RedirectAttributes rttr) throws Exception {
		
		EmpMemberVO dbemvo =  empMemberService.login(emvo);
		String url = null;
		
		  if (dbemvo != null) {
			boolean flag = bCryptPasswordEncoder.matches(emvo.getEmp_pwd(), dbemvo.getEmp_pwd());
	
			if (flag) {
				session.setAttribute("emp", dbemvo);
				session.setMaxInactiveInterval(60*10);
				url = "redirect:/";
			} else {
				session.setAttribute("emp", null);	
				rttr.addFlashAttribute("emp_pwd", false);
				url = "redirect:/login";
			} 
		} else {
	        rttr.addFlashAttribute("emp_id", false);
	        url = "redirect:/login";
			} 
			
			return url;
		}
	
		@GetMapping("/logout")
		public String logout(HttpSession session) throws Exception {
			session.invalidate();
			return "redirect:/";
		}
		
		@GetMapping("/emp_mypage")
		public String getemp(@RequestParam("emp_id") String emp_id, HttpSession session, Model model) throws Exception  {
			String url = null;
			EmpMemberVO sessionemvo = null;
			sessionemvo = (EmpMemberVO) session.getAttribute("emp");
			
			
			if (sessionemvo != null) {
				EmpMemberVO emvo = empMemberService.getEmp(emp_id);
				model.addAttribute("emvo", emvo);
				url = "/emp/member/emp_mypage";
			} else {url = "redirect:/login";}
			
			return url;
		}
		
		@GetMapping("/emp_modify")
		public void modify(@RequestParam("emp_id") String emp_id, Model model) throws Exception {
			EmpMemberVO emvo = empMemberService.getEmp(emp_id);
			model.addAttribute("emvo", emvo);
		}
		
		@PostMapping("/emp_modify")
		public String modify(EmpMemberVO emvo) throws Exception {
			int result = empMemberService.emp_modify(emvo);
			String url = null;
			
			if (result != 0) {
				url = "redirect:/emp/member/emp_mypage?emp_id="+emvo.getEmp_id();
			} else {
				url = "redirect:/emp/member/modify_ex";
			}
			
			return url;
		}
		
		// 아이디 찾기 화면
		@GetMapping("/emp_id_find")
		public void emp_id_find() throws Exception {}

		// 아이디 찾기 처리
		@PostMapping("/emp_id_find")
		public String emp_id_find(EmpMemberVO emvo, RedirectAttributes rttr) throws Exception {
		    EmpMemberVO dbemvo = empMemberService.emp_id_find(emvo);
		    String url = null;
		    
		    if (dbemvo != null) {
		        rttr.addFlashAttribute("emp_id", dbemvo.getEmp_id());
		        url = "redirect:/emp/member/emp_id_find_ok";
		    } else {
		        url = "redirect:/emp/member/emp_id_find_ex";
		    }
		    return url;
		}
		
		@GetMapping("/emp_id_find_ok")
		public void emp_id_find_ok() throws Exception {}
		
		@GetMapping("/emp_id_find_ex")
		public void emp_id_find_ex() throws Exception {}
		
		// 비밀번호 찾기 처리
		@GetMapping("/emp_pwd_find")
		public void emp_pwd_find() throws Exception {}
		
		@PostMapping("/emp_pwd_find")
		public String emp_pwd_find(EmpMemberVO emvo, RedirectAttributes rttr) throws Exception {
		    EmpMemberVO dbemvo = empMemberService.emp_pwd_find(emvo);
		    String url = null;
		    
		    if (dbemvo != null) {
		    	rttr.addFlashAttribute("emp_id", dbemvo.getEmp_id());
		        url = "redirect:/emp/member/emp_pwd_find_ok";
		    } else {
		        url = "redirect:/emp/member/emp_pwd_find_ex";
		    }
		    return url;
		}
		
		@GetMapping("/emp_pwd_find_ok")
		public void emp_pwd_find_ok() throws Exception {}
		
		@GetMapping("/emp_pwd_find_ex")
		public void emp_pwd_find_ex() throws Exception {}
		
		@GetMapping("/reset_pwd")
		public void setPwd(@RequestParam("emp_id") String emp_id, Model model) throws Exception {
			EmpMemberVO emvo = empMemberService.getEmp(emp_id);
			model.addAttribute("emvo", emvo);
		}
		
		@PostMapping("/reset_pwd")
		public String resetPwd(HttpSession session, EmpMemberVO emvo) throws Exception {
			String pwd = emvo.getEmp_pwd(); 
			String encPwd =  bCryptPasswordEncoder.encode(pwd); 
			emvo.setEmp_pwd(encPwd); 
			
			String url = null;
			int result = empMemberService.resetPwd(emvo); 
			
			if(result == 1) { 
		    	session.invalidate();
				url = "/emp/member/reset_pwd_ok"; 
			} else {
				url = "/emp/member/reset_pwd_ex";
				}
			
			return url;
		}
		
		@GetMapping("/delete")
		public String delete(@RequestParam("emp_id") String emp_id, Model model, HttpSession session) throws Exception {
			int result = empMemberService.delete(emp_id);
			String url = null;
			
			if (result != 0) {
				session.invalidate();
				url = "redirect:/";
			} else {
				url = "redirect:/emp/member/delete_ex";
			}
			return url;
		}
		
	    @GetMapping("/delete_ex")
	    public void delete_ex() throws Exception {}

}
