package org.finework.emp.member;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

@Repository
public class EmpMemberPersistenceImpl implements EmpMemberPersistence {
	
	@Inject
	private SqlSession sqlSession;
	
	private String namespace="org.finework.mappers.empmember";
	
	@Override
	public int register(EmpMemberVO emvo) throws Exception {
		return sqlSession.insert(namespace+".register", emvo);
	}
	
	@Override
	public EmpMemberVO idCheck(String emp_id) throws Exception {
		
		return sqlSession.selectOne(namespace+".idcheck", emp_id);
	}
	
	@Override
	public  EmpMemberVO nickcheck(String emp_nickname) throws Exception {
		return sqlSession.selectOne(namespace+".nickcheck", emp_nickname);
	}
	
	@Override
	public EmpMemberVO login(EmpMemberVO emvo) throws Exception{
		return sqlSession.selectOne(namespace+".login", emvo); 
	}
	
	@Override
	public EmpMemberVO getEmp(String emp_id) throws Exception{
		
		return sqlSession.selectOne(namespace+".getEmp", emp_id);
	}
	
	@Override
	public int emp_modify(EmpMemberVO emvo) throws Exception {
		return sqlSession.update(namespace+".emp_modify", emvo);
	}
	
	@Override
	public EmpMemberVO emp_id_find(EmpMemberVO emvo) throws Exception {
		return sqlSession.selectOne(namespace + ".emp_id_find", emvo);
	}
	
	@Override
	public EmpMemberVO emp_pwd_find(EmpMemberVO emvo) throws Exception {
		return sqlSession.selectOne(namespace + ".emp_pwd_find", emvo);
	}
	
	@Override
	public int resetPwd(EmpMemberVO emvo) throws Exception {
		return sqlSession.update(namespace+".resetPwd", emvo);
	}
	
	@Override
	public int delete(String emp_id) throws Exception {
		return sqlSession.delete(namespace+".delete", emp_id);
	}
	
    @Override
    public List<AddressVO> getAddrList(AddressVO addr) throws Exception {
        return sqlSession.selectList(namespace + ".getAddrList", addr);
    }
	
}
