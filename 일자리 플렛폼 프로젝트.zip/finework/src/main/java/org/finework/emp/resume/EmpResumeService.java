package org.finework.emp.resume;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;

public interface EmpResumeService {
	
	public int register(EmpResumeVO ervo) throws Exception;
	
	public List<EmpResumeVO> getResumeList(String emp_id) throws Exception;
	
	public EmpResumeVO getResume(int emp_resume_num) throws Exception;
	
	public int resume_modify(EmpResumeVO ervo) throws Exception;

	public int resume_delete(String emp_resume_num) throws Exception;
	
}

