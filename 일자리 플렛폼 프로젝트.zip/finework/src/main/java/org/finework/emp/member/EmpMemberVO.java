package org.finework.emp.member;

import java.sql.Date;

import lombok.Data;

@Data // 롬복 라이브러리 : getters and setters 메소드, toString(), 생성자 등 자동 생성
public class EmpMemberVO {
	  private String emp_id; // char(12) NOT NULL DEFAULT '' COMMENT '아이디',
	  private String emp_pwd; // char(15) NOT NULL COMMENT '비밀번호',
	  private String emp_nickname; //char(12) NOT NULL DEFAULT '' COMMENT '닉네임',
	  private String emp_birth; // DEFAULT NULL COMMENT '생년월일',
	  private String emp_name; // varchar(20) NOT NULL COMMENT '이름',
	  private String emp_phone; // char(11) NOT NULL COMMENT '전화번호',
	  private String emp_email; // varchar(30) DEFAULT NULL COMMENT '이메일',
	  private String emp_addr; // varchar(50) NOT NULL COMMENT '주소',
	  private int emp_type;   // int   DEFAULT 0 COMMENT '회원상태 (0: 비회원, 1:회원)'
	  private Date emp_reg_date; // date DEFAULT NULL COMMENT '가입일',
	  private Date emp_mod_date; // date DEFAULT NULL COMMENT '수정일',
	  
}
