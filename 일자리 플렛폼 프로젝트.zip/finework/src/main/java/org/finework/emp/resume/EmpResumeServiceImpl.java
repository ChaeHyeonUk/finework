package org.finework.emp.resume;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;

@Service // 서비스 빈으로 IoC 컨테이너에 등록된다.
public class EmpResumeServiceImpl implements EmpResumeService{
	
	@Inject
	private EmpResumePersistence empResumePersistence; 
	
	@Override
	public int register(EmpResumeVO ervo) throws Exception {
		return empResumePersistence.register(ervo);
	}
	
	@Override
	public EmpResumeVO getResume(int emp_resume_num) throws Exception {
		return empResumePersistence.getResume(emp_resume_num);
	}
	
	@Override
	public List<EmpResumeVO> getResumeList(String emp_id) throws Exception {
		return empResumePersistence.getResumeList(emp_id);
	}
	
	@Override
	public int resume_modify(EmpResumeVO ervo) throws Exception {
		return empResumePersistence.resume_modify(ervo);
	}
	
	@Override
	public int resume_delete(String emp_resume_num) throws Exception {
		return empResumePersistence.resume_delete(emp_resume_num);
	}
}
