package org.finework.emp.resume;

import java.sql.Date;

import lombok.Data;

@Data // 롬복 라이브러리 : getters and
public class EmpResumeVO {
	 private int emp_resume_num;
	 private String emp_id; //  varchar(12) NOT NULL COMMENT '아이디',
	 private String emp_school_state; // varchar(20) DEFAULT NULL COMMENT '최종학력 (학교 + 상태)'
	 private String emp_highschool_name; //  varchar(20) DEFAULT NULL COMMENT '고등학교 명',
	 private String emp_highschool_grad; //  date DEFAULT NULL COMMENT '고등학교 졸업년월',
	 private String emp_univer_name_major; //  varchar(20) DEFAULT NULL COMMENT '대학교 명 + 전공',
	 private String emp_univer_grad; //  date DEFAULT NULL COMMENT '대학교 졸업년월',
	 private String emp_gradschool_name_degree_major; //  varchar(20) DEFAULT NULL COMMENT '대학원 명 + 학위 + 전공',
	 private String emp_gradschool_grad; //  date DEFAULT NULL COMMENT '대학원 졸업년월',
	 private String emp_career; //  varchar(4) DEFAULT NULL COMMENT '신입/경력',
	 private String emp_career_info; //  text DEFAULT NULL COMMENT '경력사항',
	 private String emp_location; //  varchar(20) DEFAULT NULL COMMENT '희망 근무지'
	 private String emp_industry; //  varchar(15) DEFAULT NULL COMMENT '업직종',
	 private String emp_period; //  varchar(6) DEFAULT NULL COMMENT '근무기간',
	 private String emp_schedule; //  varchar(30) DEFAULT NULL COMMENT '근무일시 (요일+시간대)',
	 private int emp_salary_amount; //  int(11) DEFAULT NULL COMMENT '희망 급여 액수',
	 private String emp_intro; //  text COMMENT '자기소개',
	 private String emp_license_info; //  varchar(30) DEFAULT NULL COMMENT '자격증 정보 (발행처+자격증이름+연도) JSON 또는 구분자 추천',
	 private String emp_military_status; //  varchar(55) DEFAULT NULL COMMENT '병역사항 (군필/미필/면제) + 병역내용',
	 private Date emp_resume_reg_date; // date DEFAULT NULL COMMENT '가입일',
	 private Date emp_resume_mod_date; // date DEFAULT NULL COMMENT '수정일',
}
