package org.finework.emp.resume;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

@Repository
public class EmpResumePersistenceImpl implements EmpResumePersistence {
	
	@Inject
	private SqlSession sqlSession;
	private String namespace="org.finework.mappers.emp.resume";
	
	@Override
	public int register(EmpResumeVO ervo) throws Exception {
		return sqlSession.insert(namespace+".register", ervo);
	}
	
	@Override
	public EmpResumeVO getResume(int emp_resume_num) throws Exception {
		
		return sqlSession.selectOne(namespace+".getResume", emp_resume_num); 
	}
	
	@Override
	public List<EmpResumeVO> getResumeList(String emp_id) throws Exception {
		return sqlSession.selectList(namespace+".getResumeList", emp_id); 
	}
	
	@Override
	public int resume_modify(EmpResumeVO ervo) throws Exception {	
		return sqlSession.update(namespace+".resume_modify", ervo);
	}
	
	@Override
	public int resume_delete(String emp_resume_num) throws Exception{
		
		return sqlSession.delete(namespace+".resume_delete", emp_resume_num);
	}
	
}
