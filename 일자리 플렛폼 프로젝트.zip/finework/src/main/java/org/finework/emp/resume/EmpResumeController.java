package org.finework.emp.resume;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.finework.emp.member.EmpMemberVO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/emp/resume/*")
public class EmpResumeController {
	
	@Inject 
	private EmpResumeService empResumeService;
	
	@GetMapping("/resume")
	public String resume(@RequestParam("emp_id") String emp_id, Model model) throws Exception {
		
		List<EmpResumeVO> erList = empResumeService.getResumeList(emp_id);
		model.addAttribute("erList", erList );
		
		return "/emp/resume/resume";
	}

	@GetMapping("/register")
	public void register() throws Exception  {}
	
	@PostMapping("/register")
	public String register(HttpServletRequest request,EmpResumeVO ervo) throws Exception {

		String emp_school_name = request.getParameter("emp_school_name");
		String emp_school_state = request.getParameter("emp_school_state");
		ervo.setEmp_school_state(emp_school_name+" "+emp_school_state);
		
		String emp_univer_name = request.getParameter("emp_univer_name");
		String emp_univer_major= request.getParameter("emp_univer_major");
		ervo.setEmp_univer_name_major(emp_univer_name +" "+emp_univer_major);

		String emp_gradschool_name = request.getParameter("emp_gradschool_name");
		String emp_gradschool_degree = request.getParameter("emp_gradschool_degree");
		String emp_gradschool_major = request.getParameter("emp_gradschool_major");
		ervo.setEmp_gradschool_name_degree_major(emp_gradschool_name+" "+emp_gradschool_degree+" "+emp_gradschool_major);	
		 
		String work_days = request.getParameter("work_days");
		String work_hours = request.getParameter("work_hours");
		ervo.setEmp_schedule(work_days+" "+work_hours);
		
		String cert_name = request.getParameter("cert_name");
		String cert_org = request.getParameter("cert_org");
		String cert_date = request.getParameter("cert_date");
		ervo.setEmp_license_info(cert_name+" "+cert_org+" "+cert_date);

		String military_info = request.getParameter("military_info");
		String military_detail = request.getParameter("military_detail");
		ervo.setEmp_military_status(military_info+" "+military_detail);

		int result = empResumeService.register(ervo);

		String url = null;
		
		if(result == 1) {
			url = "/emp/resume/register_ok"; 
		} else {
			url = "/emp/resume/register_ex";
			}
		
		return url;
	}
	
    @GetMapping("/resume_detail")
    public String detail(@RequestParam("emp_resume_num") int emp_resume_num, Model model) throws Exception {
    	
    	EmpResumeVO ervo = empResumeService.getResume(emp_resume_num);
    	
        model.addAttribute("ervo", ervo);
        
        return "/emp/resume/resume_detail";
    }
	
	@GetMapping("/resume_modify")
	public String resume_modify(@RequestParam("emp_resume_num") int emp_resume_num, Model model) throws Exception {
		
		EmpResumeVO ervo = empResumeService.getResume(emp_resume_num);
		
		String emp_school_state = ervo.getEmp_school_state();
	    String[] school_state_Array = emp_school_state.split(" ");
	    model.addAttribute("school_state_Array", school_state_Array);
	    
	    String emp_univer_name_major = ervo.getEmp_univer_name_major();
	    String[] emp_univer_Array = emp_univer_name_major.split(" ");
	    model.addAttribute("univer_Array", emp_univer_Array);
	    
	    String emp_gradschool_name_degree_major = ervo.getEmp_gradschool_name_degree_major();
	    String[] emp_gradschool_Array = emp_gradschool_name_degree_major.split(" ");
	    model.addAttribute("gradschool_Array", emp_gradschool_Array);
	    
	    String emp_schedule = ervo.getEmp_schedule();
	    String[] emp_schedule_Array = emp_schedule.split(" ");
	    model.addAttribute("schedule_Array", emp_schedule_Array);
	    
	    String emp_license_info = ervo.getEmp_license_info();
	    String[] emp_license_info_Array = emp_license_info.split(" ");
	    model.addAttribute("license_info_Array", emp_license_info_Array);
	    
	    String emp_military_status = ervo.getEmp_military_status();
	    String[] emp_military_status_Array = emp_military_status.split(" ");
	    model.addAttribute("military_status_Array", emp_military_status_Array);

		model.addAttribute("ervo", ervo);
		
		return "/emp/resume/resume_modify";
	};
	
	@PostMapping("/resume_modify")
	public String resume_modify(HttpServletRequest request, EmpResumeVO ervo) throws Exception {
		
		String emp_school_name = request.getParameter("emp_school_name");
		String emp_school_state = request.getParameter("emp_school_state");
		ervo.setEmp_school_state(emp_school_name+" "+emp_school_state);
		
		String emp_univer_name = request.getParameter("emp_univer_name");
		String emp_univer_major= request.getParameter("emp_univer_major");
		ervo.setEmp_univer_name_major(emp_univer_name +" "+emp_univer_major);

		String emp_gradshool_name = request.getParameter("emp_gradshool_name");
		String emp_gradshool_degree = request.getParameter("emp_gradshool_degree");
		String emp_gradshool_major = request.getParameter("emp_gradshool_major");
		ervo.setEmp_gradschool_name_degree_major(emp_gradshool_name+" "+emp_gradshool_degree+" "+emp_gradshool_major);	
		 
		String work_days = request.getParameter("work_days");
		String work_hours = request.getParameter("work_hours");
		ervo.setEmp_schedule(work_days+" "+work_hours);
		
		String cert_name = request.getParameter("cert_name");
		String cert_org = request.getParameter("cert_org");
		String cert_date = request.getParameter("cert_date");
		ervo.setEmp_license_info(cert_name+" "+cert_org+" "+cert_date);

		String military_info = request.getParameter("military_info");
		String military_detail = request.getParameter("military_detail");
		ervo.setEmp_military_status(military_info+" "+military_detail);

		int result = empResumeService.resume_modify(ervo);

		String url = null;
		
		if(result != 0) {
			url = "/emp/resume/resume_modify_ok"; 
		} else {
			url = "/emp/resume/resume_modify_ex";
		}
		
		return url;
	}
	
	@GetMapping("/resume_modify_ok")
	public void resume_modify_ok() throws Exception  {}
	
	@GetMapping("/resume_modify_ex")
	public void resume_modify_ex() throws Exception  {}
	
	@GetMapping("/resume_delete")
	public String resume_delete(@RequestParam("emp_resume_num") String emp_resume_num) throws Exception  {
	
		int result = empResumeService.resume_delete(emp_resume_num);
		String url = null;
		
		if (result != 0) {
			url = "redirect:/emp/resume/resume_delete_ok";
		} else {
			url = "/emp/resume/resume_delete_ex";
		}
		
		return url;
	}
	
	@GetMapping("/resume_delete_ok")
	public void resume_delete_ok() throws Exception  {}
	
	@GetMapping("/resume_delete_ex")
	public void resume_delete_ex() throws Exception  {}
	
	}
