package org.finework.emp.member;

import java.util.List;

import org.springframework.web.bind.annotation.RequestParam;

public interface EmpMemberPersistence {
	
	public EmpMemberVO idCheck(String emp_id) throws Exception;
	
	public  EmpMemberVO nickcheck(String emp_nickname) throws Exception;

	public int register(EmpMemberVO emvo) throws Exception;
	
	public EmpMemberVO login(EmpMemberVO emvo) throws Exception;
	
	public EmpMemberVO getEmp(String emp_id) throws Exception;
	
	public int emp_modify(EmpMemberVO emvo) throws Exception;	
	
	public EmpMemberVO emp_id_find(EmpMemberVO emvo) throws Exception;
	
	public EmpMemberVO emp_pwd_find(EmpMemberVO emvo) throws Exception;
	
	public int resetPwd(EmpMemberVO emvo) throws Exception;
	
	public int delete(String emp_id) throws Exception;
	
	public List<AddressVO> getAddrList(AddressVO addr) throws Exception;
}
