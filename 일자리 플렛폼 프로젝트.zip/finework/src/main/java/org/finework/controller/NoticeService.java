package org.finework.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;

public interface NoticeService {
	
	public List<NoticeVO> getNoticeList() throws Exception;

}
	