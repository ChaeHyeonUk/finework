package org.finework.controller;

import java.util.List;

import javax.inject.Inject;

import org.finework.com.member.ComMemberVO;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;

@Service // 서비스 빈으로 IoC 컨테이너에 등록된다.
public class NoticeServiceImpl implements NoticeService{
	
	    @Inject
	    private NoticePersistence NoticePersistence;
	    
	    @Override
	    public List<NoticeVO> getNoticeList() throws Exception {
	        return NoticePersistence.getNoticeList();
	    }

	}
