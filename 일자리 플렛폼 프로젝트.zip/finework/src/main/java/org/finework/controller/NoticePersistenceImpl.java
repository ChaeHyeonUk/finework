package org.finework.controller;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.finework.com.member.ComMemberVO;
import org.springframework.stereotype.Repository;

@Repository
public class NoticePersistenceImpl implements NoticePersistence {

    @Inject
    private SqlSession sqlSession;

    private static final String namespace = "org.finework.mapper.ComNoticeMapper";

    @Override
    public List<NoticeVO> getNoticeList() throws Exception {
        return sqlSession.selectList(namespace + ".getNoticeList");
    }

}
