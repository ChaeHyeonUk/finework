package org.finework.controller;


import java.util.List;

import org.finework.com.member.ComMemberVO;
import org.springframework.web.bind.annotation.RequestParam;

public interface NoticePersistence {
	
	 public List<NoticeVO> getNoticeList() throws Exception;

}

