package org.finework.statics;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/static")
public class StaticController {

	@GetMapping("/")
	public String index() { return "/static/index";}
	
	@GetMapping("/company")
	public void company() {}
	
	@GetMapping("/support")
	public void support() {}
	
	@GetMapping("/aptitude")
	public void aptitude() {}
	
}