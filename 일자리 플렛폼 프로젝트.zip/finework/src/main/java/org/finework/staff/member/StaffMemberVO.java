package org.finework.staff.member;

import java.util.Date;

import lombok.Data;

@Data // getters and setters 메소드, toString(), 생성자 등 자동 생성
public class StaffMemberVO {
	
    private String staff_id; // '사번'
    private String staff_pwd; // '비밀번호'
    private String staff_name; // '이름'
    private String staff_gender; // '성별'
    private String staff_phone; // '전화번호'
    private String staff_email; // '이메일'
    private String staff_part; // '부서(C/S부, 광고부, 사업부)'
    private String staff_pos; // '직급'
    private int staff_approval; // '승인여부(0:미승인, 1:승인)'
    private Date staff_reg_date; // '등록일'
    private Date staff_mod_date; // '수정일'
	
}
