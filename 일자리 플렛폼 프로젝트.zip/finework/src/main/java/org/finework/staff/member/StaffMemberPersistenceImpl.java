package org.finework.staff.member;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.finework.emp.member.EmpMemberVO;
import org.springframework.stereotype.Repository;

@Repository // IoC 컨테이너에 Persistence 빈으로 등록한다.
public class StaffMemberPersistenceImpl implements StaffMemberPersistence {
	
	@Inject
	private SqlSession sqlSession; // SQL문을 실행하는 빈을 주입한다.
	
	private String namespace="org.finework.mappers.staffmember";
	

	@Override
	public StaffMemberVO idCheck(String staff_id) throws Exception {
		return sqlSession.selectOne(namespace+".idcheck", staff_id);
	}
	
	@Override
	public int register(StaffMemberVO smvo) throws Exception {
		return sqlSession.insert(namespace+".register", smvo);
	}

	@Override
	public StaffMemberVO login(StaffMemberVO smvo) throws Exception {
		return sqlSession.selectOne(namespace+".login", smvo);
	}

	@Override
	public List<StaffMemberVO> getStaffList() throws Exception {
		return sqlSession.selectList(namespace+".getStaffList");
	}

	@Override
	public List<StaffMemberVO> getList(String staff_part) throws Exception {
		return sqlSession.selectList(namespace+".getPartList", staff_part);
	}

	@Override
	public void setApproval(String staff_id) throws Exception {
		sqlSession.update(namespace+".setApproval", staff_id);
	}
	
	@Override
	public void cancellApproval(String staff_id) throws Exception {
		sqlSession.update(namespace+".cancellApproval", staff_id);
	}

	@Override
	public StaffMemberVO getStaff(String staff_id) throws Exception {
		return sqlSession.selectOne(namespace+".getStaff", staff_id);
	}

	@Override
	public int modify(StaffMemberVO smvo) throws Exception {
		return sqlSession.update(namespace+".modify", smvo);
	}
	
	@Override
	public void admModify(StaffMemberVO smvo) throws Exception {
		sqlSession.update(namespace+".admModify", smvo);
	}
	
	@Override
	public int resetPwd(StaffMemberVO smvo) throws Exception {
		return sqlSession.update(namespace+".resetPwd", smvo);
	}
	
	@Override
	public List<EmpMemberVO> getEmpList() throws Exception {
		return sqlSession.selectList(namespace+".getEmpList");
	}
	
	@Override
	public List<ComMemberVO> getComList() throws Exception {
		return sqlSession.selectList(namespace+".getComList");
	}
	
	@Override
	public List<ComNoticeVO> getNoticeList() throws Exception {
		return sqlSession.selectList(namespace+".getNoticeList");
	}
	
	@Override
	public List<EmpResumeVO> getResumeList() throws Exception {
		return sqlSession.selectList(namespace+".getResumeList");
	}
	
	@Override
	public void emp_type_on(String emp_id) throws Exception {
		sqlSession.update(namespace+".emp_type_on", emp_id);
	}
	
	@Override
	public void com_type_on(String com_id) throws Exception {
		sqlSession.update(namespace+".com_type_on", com_id);
	}

}

















