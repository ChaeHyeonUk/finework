package org.finework.staff.member;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.finework.emp.member.EmpMemberVO;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

public interface StaffMemberService {
	
	public StaffMemberVO idCheck(String staff_id) throws Exception;
	
	public int register(StaffMemberVO smvo) throws Exception;
	
	public StaffMemberVO login(StaffMemberVO smvo) throws Exception;
	
	public List<StaffMemberVO> getStaffList() throws Exception;
	
	public List<StaffMemberVO> getList(String staff_part) throws Exception;
	
	public void setApproval(String staff_id) throws Exception;
	
	public void cancellApproval(String staff_id) throws Exception;
	
	public StaffMemberVO getStaff(String staff_id) throws Exception;
	
	public int modify(StaffMemberVO smvo) throws Exception;
	
	public void admModify(StaffMemberVO smvo) throws Exception;
	
	public int resetPwd(StaffMemberVO smvo) throws Exception;
	
	public List<EmpMemberVO> getEmpList() throws Exception;
	
	public List<ComMemberVO> getComList() throws Exception;
	
	public List<ComNoticeVO> getNoticeList() throws Exception;
	
	public List<EmpResumeVO> getResumeList() throws Exception;
	
	public void emp_type_on(String emp_id) throws Exception;
	
	public void com_type_on(String com_id) throws Exception;
	
}










