package org.finework.staff.member;

import java.sql.Date;

import lombok.Data;

@Data 
public class ComMemberVO {
	  private String com_id; 
	  private String com_pwd; 
	  private String com_name;
	  private String  com_phone;
	  private String com_company_name;
	  private String com_email; 
	  private String com_addr;
	  private String com_employees;
	  private int com_type;
	  private Date com_reg_date; 
	  private Date com_mod_date; 
}
