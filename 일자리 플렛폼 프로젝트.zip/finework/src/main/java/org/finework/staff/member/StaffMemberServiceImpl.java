package org.finework.staff.member;

import java.util.List;

import javax.inject.Inject;

import org.finework.emp.member.EmpMemberVO;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

@Service // 서비스 빈으로 IoC 컨테이너에 등록된다.
public class StaffMemberServiceImpl implements StaffMemberService {
	
	@Inject // IoC 컨터이너에서 StaffMemberPersistence 빈을 주입한다.
	private StaffMemberPersistence staffMemberPersistence;
	

	@Override
	public StaffMemberVO idCheck(String staff_id) throws Exception {
		return staffMemberPersistence.idCheck(staff_id);
	}
	
	@Override
	public int register(StaffMemberVO smvo) throws Exception {
		return staffMemberPersistence.register(smvo); // 성공 : 1, 실패 : 0
	}

	@Override
	public StaffMemberVO login(StaffMemberVO smvo) throws Exception {
		return staffMemberPersistence.login(smvo);
	}

	@Override
	public List<StaffMemberVO> getStaffList() throws Exception {
		return staffMemberPersistence.getStaffList();
	}

	@Override
	public List<StaffMemberVO> getList(String staff_part) throws Exception {
		return staffMemberPersistence.getList(staff_part);
	}

	@Override
	public void setApproval(String staff_id) throws Exception {
		staffMemberPersistence.setApproval(staff_id);
	} 

	@Override
	public void cancellApproval(String staff_id) throws Exception {
		staffMemberPersistence.cancellApproval(staff_id);
	}
	
	@Override
	public StaffMemberVO getStaff(String staff_id) throws Exception {
		return staffMemberPersistence.getStaff(staff_id);
	}

	@Override
	public int modify(StaffMemberVO smvo) throws Exception {
		return staffMemberPersistence.modify(smvo);
	}
	
	@Override
	public void admModify(StaffMemberVO smvo) throws Exception {
		staffMemberPersistence.admModify(smvo);
	}

	@Override
	public int resetPwd(StaffMemberVO smvo) throws Exception {
		return staffMemberPersistence.resetPwd(smvo);
	}
	
	@Override
	public List<EmpMemberVO> getEmpList() throws Exception {
		return staffMemberPersistence.getEmpList();
	};

	@Override
	public List<ComMemberVO> getComList() throws Exception {
		return staffMemberPersistence.getComList();
	};
	
	@Override
	public List<ComNoticeVO> getNoticeList() throws Exception {
		return staffMemberPersistence.getNoticeList();
	}
	
	@Override
	public List<EmpResumeVO> getResumeList() throws Exception {
		return staffMemberPersistence.getResumeList();
	}
	
	@Override
	public void emp_type_on(String emp_id) throws Exception {
		staffMemberPersistence.emp_type_on(emp_id);
	}
	
	
	@Override
	public void com_type_on(String com_id) throws Exception{
		staffMemberPersistence.com_type_on(com_id);
	}
	
}




















