package org.finework.staff.member;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.finework.emp.member.EmpMemberVO;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/staff/member/*")
public class StaffMemberController {
	

	@Inject 
	private StaffMemberService staffMemberService;
	
	@Inject
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	
	@PostMapping("/idcheck")
	@ResponseBody
	public String idCheck(HttpServletRequest request) throws Exception {
		String staff_id = request.getParameter("staff_id");
		
		StaffMemberVO smvo = staffMemberService.idCheck(staff_id);
		String result = null;
		
		if (smvo != null) result = "success";
		
		return result;
	}
		
	@GetMapping("/register")
	public void register() throws Exception {}
	
	@PostMapping("/register")
	public String register(StaffMemberVO smvo) throws Exception {
		String pwd = smvo.getStaff_pwd();
		String encPwd = bCryptPasswordEncoder.encode(pwd);
		smvo.setStaff_pwd(encPwd);
		
		int result = staffMemberService.register(smvo);
		
		String url = null;
		
		if (result == 1) {
			url = "/staff/member/register_ok";
		} else {
			url = "/staff/member/register_ex";
		}
		
		return url;
	}
	
	@GetMapping("/login")
	public void login() throws Exception {}
	// 반환형이 void이면 사용자 URL 요청(/staff/member/login)에 해당하는 JSP 페이지를 응답 페이지(/staff/member/login.jsp)로 지정한다.
	
	@PostMapping("/login")
	public String login(StaffMemberVO smvo, HttpSession session, RedirectAttributes rttr) throws Exception {
		StaffMemberVO dbSmvo = staffMemberService.login(smvo);
		
		String url = null; 
		
		if (dbSmvo != null && dbSmvo.getStaff_approval() == 1) { // 사원 + 승인된 상태
			boolean flag = bCryptPasswordEncoder.matches(smvo.getStaff_pwd(), dbSmvo.getStaff_pwd());

			if (flag) { 
				session.setAttribute("staff", dbSmvo);
				session.setMaxInactiveInterval(60 * 10);
				url = "redirect:/staff";
			} else { 
				session.setAttribute("staff", null);
				rttr.addFlashAttribute("staff_pwd", false);
				url = "redirect:/staff/member/login";
			}
		} else {
			session.setAttribute("staff", null);
			rttr.addFlashAttribute("staff_approval", false);
			url = "redirect:/staff/member/login";
		}
		
		return url;
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) throws Exception {
		session.invalidate(); // 세션의 정보를 소멸시킨다.
		return "redirect:/staff";
	}
	
	@GetMapping("/staff_list")
	public void getStaffList(Model model) throws Exception {
		List<StaffMemberVO> smList = staffMemberService.getStaffList();
		model.addAttribute("smList", smList);
	}
	
	@GetMapping("/approval")
	public String setApproval(@RequestParam("staff_id") String staff_id, HttpSession session) throws Exception {
		String url = null;
		StaffMemberVO sessionSmvo = null;
		sessionSmvo = (StaffMemberVO) session.getAttribute("staff");
		
		if (sessionSmvo != null) {
			staffMemberService.setApproval(staff_id);
			url = "redirect:/staff/member/staff_list";
		} else { 
			url = "redirect:/staff/member/login";
		}
		
		return url;
	}
	
	@GetMapping("/approval_cancell")
	public String cancellApproval(@RequestParam("staff_id") String staff_id, HttpSession session) throws Exception {
		String url = null;
		StaffMemberVO sessionSmvo = null;
		sessionSmvo = (StaffMemberVO) session.getAttribute("staff");
		
		if (sessionSmvo != null) {
			staffMemberService.cancellApproval(staff_id);
			url = "redirect:/staff/member/staff_list";
		} else { 
			url = "redirect:/staff/member/login"; 
		}
		
		return url;
	}
	
	@GetMapping("/list_part")
	public void getList(@RequestParam("staff_part") String staff_part, Model model) throws Exception {
		List<StaffMemberVO> smList = staffMemberService.getList(staff_part);
		model.addAttribute("smList", smList);
	}
	
	@GetMapping("/mypage")
	public String getStaff(@RequestParam("staff_id") String staff_id, HttpSession session, Model model) throws Exception {
		
		String url = null;
		StaffMemberVO sessionSmvo = null;
		sessionSmvo = (StaffMemberVO) session.getAttribute("staff");
		
		if (sessionSmvo != null) { // 로그인 상태
			StaffMemberVO smvo = staffMemberService.getStaff(staff_id);
			model.addAttribute("smvo", smvo);
			url = "/staff/member/mypage";
		} else {
			url = "redirect:/staff/member/login";
		}
		
		return url;
	}
	
	@GetMapping("/modify")
	public void modify(@RequestParam("staff_id") String staff_id, Model model) throws Exception {
		StaffMemberVO smvo = staffMemberService.getStaff(staff_id);
		model.addAttribute("smvo", smvo);
	}
	
	@PostMapping("/modify")
	public String modify(StaffMemberVO smvo) throws Exception {
		int result = staffMemberService.modify(smvo);
		String url = null;
			
		if (result != 0) {
			url = "redirect:/staff/member/mypage?staff_id="+smvo.getStaff_id();
		} else {
			url = "redirect:/staff/member/modify_ex";
		}
		
		return url;
	}
	
	@GetMapping("/adm_modify")
	public void admModify(@RequestParam("staff_id") String staff_id, Model model) throws Exception {
		StaffMemberVO smvo = staffMemberService.getStaff(staff_id);
		model.addAttribute("smvo", smvo);
	}
	
	@PostMapping("/adm_modify")
	public String admModify(StaffMemberVO smvo) throws Exception {
		staffMemberService.admModify(smvo);
		return "redirect:/staff/member/staff_list";
	}
	
	@GetMapping("/reset_pwd")
	public void setPwd(@RequestParam("staff_id") String staff_id, Model model) throws Exception {
		StaffMemberVO smvo = staffMemberService.getStaff(staff_id);
		model.addAttribute("smvo", smvo);
	}
	
	@PostMapping("/reset_pwd")
	public String resetPwd(StaffMemberVO smvo) throws Exception { // smvo에는 staff_id, staff_pwd 값이 있다.
		String pwd = smvo.getStaff_pwd(); // 입력폼에 입력한 비밀번호를 얻는다.
		String encPwd = bCryptPasswordEncoder.encode(pwd); // 비밀번호를 encode()로 암호화한다.
		smvo.setStaff_pwd(encPwd); // 암호화된 비밀번호를 smvo에 설정한다.
		
		String url = null;
		int result = staffMemberService.resetPwd(smvo);
		
		if (result != 0) {
			url = "/staff/member/reset_pwd_ok";
		} else {
			url = "/staff/member/reset_pwd_ex";
		}
		
		return url;
	}
	
	@GetMapping("/emp_list")
	public void getEmpList(Model model) throws Exception {
		List<EmpMemberVO> emList = staffMemberService.getEmpList();
		model.addAttribute("emList", emList);
	}
	
	@GetMapping("/emp_type_on")
	public String emp_type_on(@RequestParam("emp_id") String emp_id, HttpSession session) throws Exception {
		String url = null;
		StaffMemberVO sessionSmvo = null;
		sessionSmvo = (StaffMemberVO) session.getAttribute("staff");
		
		if (sessionSmvo != null) {
			staffMemberService.emp_type_on(emp_id);
			url = "redirect:/staff/member/emp_list";
		} else { 
			url = "redirect:/staff/member/login";
		}
		
		return url;
	}
	
	@GetMapping("/com_list")
	public void getComList(Model model) throws Exception {
		List<ComMemberVO> emList = staffMemberService.getComList();
		model.addAttribute("cmList", emList);
	}
	
	@GetMapping("/com_type_on")
	public String com_type_on(@RequestParam("com_id") String com_id, HttpSession session) throws Exception {
		String url = null;
		StaffMemberVO sessionSmvo = null;
		sessionSmvo = (StaffMemberVO) session.getAttribute("staff");
		
		if (sessionSmvo != null) {
			staffMemberService.com_type_on(com_id);
			url = "redirect:/staff/member/com_list";
		} else { 
			url = "redirect:/staff/member/login";
		}
		
		return url;
	}
	
	@GetMapping("/notice_list")
	public void getNoticeList(Model model) throws Exception {
		List<ComNoticeVO> cnList = staffMemberService.getNoticeList();
		model.addAttribute("cnList", cnList);
	}
	
	@GetMapping("/resume_list")
	public void getResumeList(Model model) throws Exception {
		List<EmpResumeVO> erList = staffMemberService.getResumeList();
		model.addAttribute("erList", erList);
	}

}
























