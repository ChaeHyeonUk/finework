package org.finework.util;

import java.io.File;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service // UploadFileService 클래스를 서비스 빈으로 등록한다.
public class UploadFileService { // 첨부 파일 업로드 기능 구현 클래스

	public String upload(MultipartFile file) { // 물리적 첨부 파일 업로드에 성공한 첨부 파일명을 StaffBookController로 반환한다.
		boolean result = false;
		
		String fileOriName = file.getOriginalFilename();
		// 컴퓨터에서 선택한 첨부 파일명
		String fileExtension = fileOriName.substring(fileOriName.lastIndexOf("."), fileOriName.length());
		// 첨부 파일의 확장자명
		String uploadDir = "C:\\all-in-one\\workspace\\bookrental\\src\\main\\webapp\\resources\\upload\\";
		// 첨부 파일의 저장 경로
		
		UUID uuid = UUID.randomUUID();
		// UUID.randomUUID()는 첨부 파일의 덮어쓰기 방지를 위해 랜덤한 첨부 파일명(유일한 식별자)를 얻는다.
		String uniqueName = uuid.toString().replaceAll("-", ""); // replaceAll("-", "")는 "-"를 ""(없음)로 변경한다.
		// 서버에 저장되는 첨부 파일명으로 내 컴퓨터에서 선택한 첨부 파일명을 랜덤한 UUID 파일명으로 변경한다.
		
		File saveFile = new File(uploadDir + "\\" + uniqueName + fileExtension);
		// 첨부 파일 저장 경로 + 첨부 파일명 + 첨부 파일 확장자명으로 File 객체(saveFile)를 생성한다.
		
		if (!saveFile.exists()) saveFile.mkdirs();
		// 첨부 파일 저장 경로가 없으면 mkdirs()로 경로를 생성한다.
		
		try {
			file.transferTo(saveFile);
			// MultipartFile 객체의 transferTo()로 첨부 파일을 첨부 파일 업로드 경로에 저장한다.
			result = true; // 첨부 파일 저장에 성공하면 result에 true를 저장한다.
		}
		catch (Exception e) { e.printStackTrace(); }
		
		if (result) {
			System.out.println("========== ATTACHED FILE UPLOAD SUCCESS!! ==========");
			return uniqueName + fileExtension; // 첨부 파일명 + 확장자명을 반환한다.
		} else {
			System.out.println("========== ATTACHED FILE UPLOAD FAIL!! ==========");
			return null;
		}
	}
	
}










