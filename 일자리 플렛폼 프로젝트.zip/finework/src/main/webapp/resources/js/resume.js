  $(function () {
    $('input[name="emp_career"]').on('change', function () {
      const val = $(this).val();
      if (val === '경력') {
        $('#experienced-form').show();
      } else {
        $('#experienced-form').hide();
      }
    });
    
        $('#school-select').on('change', function () {
    	const selectedForm = $(this).find(':selected').data('form');
    	const allForms = $('.form-box');
        allForms.hide();
        if (selectedForm) {
        	   $(`.form-box[data-form="${selectedForm}"]`).show();
        }
        
    });   
  });

